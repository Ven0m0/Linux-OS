// ==UserScript==
// @name         Amazon: URL Cleaner
// @description  Replace the URL with the shortest possible clean URL for Amazon items
// @author       Rami S Ejailat
// @copyright    RamiEjailat (https://openuserjs.org/users/RamiEjailat)
// @license      MIT
// @version      20250131
// @namespace    http://tampermonkey.net/
// @include      *://*.amazon.tld/dp/*
// @include      *://*.amazon.tld/*/dp/*
// @include      *://*.amazon.tld/gp/product/*
// @include      *://*.amazon.tld/*/ASIN/*
// @grant        none
// @icon         https://www.amazon.com/favicon.ico
// @run-at       document-start
// ==/UserScript==
/* jshint esversion: 6 */
!function(){'use strict';
// Early exit if the URL doesn't match any expected patterns
if(!/(?:dp|gp\/product|ASIN)\//.test(document.location.href))return;const productId=function(){const match=document.location.href.match(/(?:\/.+\/)?(?:dp|gp\/product|ASIN)\/([^\/?]+)/);return match?match[1]:null}();if(productId&&/^[A-Z0-9]+$/.test(productId)){const cleanUrl=`https://${window.location.hostname}/dp/${productId}`;history.replaceState({},document.title,cleanUrl)}else console.error('Invalid product ID or URL:',productId,document.location.href)}();